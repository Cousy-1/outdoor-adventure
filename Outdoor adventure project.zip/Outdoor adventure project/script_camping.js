const equipmentData = [
            { id: 1, name: 'Tent', price: 2500 },
            { id: 2, name: 'Sleeping Bag', price: 1000 },
            { id: 3, name: 'Camping Stove', price: 1500 },
            // Add more equipment items as needed
        ];

        function displayEquipment() {
            const equipmentListDiv = document.getElementById('equipment-list');

            equipmentData.forEach(equipment => {
                const equipmentItemDiv = document.createElement('div');
                equipmentItemDiv.classList.add('gear-item');
                equipmentItemDiv.innerHTML = `
                    <span>${equipment.name} - KES ${equipment.price.toLocaleString()}</span>
                    <button onclick="rentEquipment(${equipment.id})">Rent</button>
                `;
                equipmentListDiv.appendChild(equipmentItemDiv);
            });
        }

        function rentEquipment(equipmentId) {
            alert(`You rented equipment with ID ${equipmentId}. This is a dummy function.`);
        }

        window.onload = displayEquipment;
    

  






 



















































