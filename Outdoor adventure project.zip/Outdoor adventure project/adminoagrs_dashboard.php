<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "outdooradventure_equipments";

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_gear'])) {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO inventory (gear_type, gear_name,price) VALUES (?, ?)");
    $stmt->bind_param("ss", $gear_type, $gear_name, $price);

    // Get data from form
    $gear_type = $_POST['gear_type'];
    $gear_name = $_POST['gear_name'];
    $price = $_POST['price'];

    // Execute SQL statement
    if ($stmt->execute() === TRUE) {
        echo "New gear added successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}

// Viewing and replying to inquiries can be implemented similarly
// Fetch inquiries from the database and display them in a table
// Provide a form or interface for the admin to reply to inquiries
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        h1, h2 {
            text-align: center;
        }

        form {
            margin: 20px auto;
            width: 50%;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>
    <h1>Welcome to Admin Dashboard</h1>

    <!-- Gear Management Form -->
    <h2>Add Gear and Gear Type</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="gear_type">Gear Type:</label>
        <input type="text" id="gear_type" name="gear_type" required><br>
        
        <label for="gear_name">Gear Name:</label>
        <input type="text" id="gear_name" name="gear_name" required><br>
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" required><br>


        <input type="submit" name="submit_gear" value="Add Gear">
    </form>

    <!-- Inquiry Management Section -->
    <h2>Inquiries</h2>
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Inquiry</th>
                <th>Reply</th>
            </tr>
        </thead>
        <tbody>
            <!-- Fetch and display inquiries dynamically -->
            <!-- <tr>
                <td>John Doe</td>
                <td>john@example.com</td>
                <td>How can I rent a bike?</td>
                <td>
                    <form action="#" method="post">
                        <textarea name="reply" rows="2" cols="30" required></textarea><br>
                        <input type="submit" value="Send Reply">
                    </form>
                </td>
            </tr> -->
        </tbody>
    </table>

</body>

</html>
