<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles_login.css"> <!-- Add your CSS file for styling -->
    <title>Outdoor Adventure Login</title>
    <style>
        /* Your CSS styles here */
    </style>
</head>

<body>
    <?php
    // Assuming you have a MySQL connection
    $servername = "localhost"; // Change to your MySQL server hostname or IP address
    $username = "root";
    $password = "";
    $dbname = "outdooradventure_equipments";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Process form data
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $email = $_POST["email"];
        $password = $_POST["password"];

        // Query to check if the user exists
        $sql = "SELECT * FROM user_accounts WHERE email = '$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row["password"])) {
                // Login successful, redirect to homepage
                header("Location: homepage.php");
                exit(); // Stop further execution after redirection
            } else {
                echo "Invalid email or password";
            }
        } else {
            echo "Invalid email or password";
        }
    }

    $conn->close();
    ?>

    <div class="login-container">
        <h2>Login to Outdoor Adventure</h2>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Login</button>
        </form>

        <!-- Add the link to login as admin -->
        <p><a href="admin_login.php">Login as Admin</a></p>
    </div>
</body>

</html>
