<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adventure Gear Rental Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #007bff;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        section {
            padding: 20px;
        }

        .category-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 20px;
        }

        .category-title {
            color: #007bff;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .category-list {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .category-list li {
            margin-bottom: 10px;
        }

        footer {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>

<body>

    <header>
        <h1>Adventure Gear Rental Dashboard</h1>
    </header>

    <section>
        <?php
        // Database connection
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "outdooradventure_equipments";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to retrieve categories
        $sql = "SELECT * FROM categories";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo "<div class='category-container'>";
                echo "<h2 class='category-title'>" . $row["category_name"] . "</h2>";
                
                // Query to retrieve equipment for this category
                $category_id = $row["category_id"];
                $equipment_sql = "SELECT * FROM equipments WHERE category_id = $category_id";
                $equipment_result = $conn->query($equipment_sql);
                
                if ($equipment_result->num_rows > 0) {
                    echo "<ul class='category-list'>";
                    while ($equipment_row = $equipment_result->fetch_assoc()) {
                        echo "<li>" . $equipment_row["name"] . "</li>";
                    }
                    echo "</ul>";
                } else {
                    echo "No equipment available for this category.";
                }

                echo "</div>";
            }
        } else {
            echo "No categories available at the moment.";
        }

        // Close connection
        $conn->close();
        ?>
    </section>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Adventure Gear Rental</p>
    </footer>

</body>

</html>
