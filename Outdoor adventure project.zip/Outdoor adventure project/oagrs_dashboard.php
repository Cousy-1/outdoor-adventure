<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adventure Gear Rental Dashboard</title>
    <link rel="stylesheet" href="styles_categories.css">
    <style>
      body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
    color: #333;
    margin: 0;
    padding: 0;
}

header {
    background-color: #007bff;
    color: #fff;
    padding: 20px;
    text-align: center;
}

#categories {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
}

.category-container {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
    padding: 20px;
    width: 30%; /* Adjust as needed */
    transition: transform 0.3s ease; /* Transition for movement effect */
}

.category-title {
    color: #007bff;
    margin-bottom: 10px;
    text-transform: uppercase;
}

.equipment-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

.equipment-list li {
    margin-bottom: 10px;
}

/* Movement effect on hover */
.category-container:hover {
    transform: translateY(-5px); /* Adjust the value as needed */
}


    </style>
</head>

<body>

    <header>
        <h1>Adventure Gear Rental Dashboard</h1>
    </header>

   

<section id="categories">
  

<footer>
    <p>&copy; 2024 Adventure Gear Rental</p>
</footer>

</body>

        

      <?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "outdooradventure_equipments";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to retrieve distinct gear types
$sql = "SELECT DISTINCT gear_type FROM inventory"; // Assuming gear_type is the column name for gear types
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        $gear_type = $row["gear_type"];

        echo "<div class='category-container'>";
        echo "<h2 class='category-title'>" . $gear_type . "</h2>";

        // Query to retrieve equipment for this gear type
        $inventory_sql = "SELECT * FROM inventory WHERE gear_type = '$gear_type'";
        $inventory_result = $conn->query($inventory_sql);

        if ($inventory_result->num_rows > 0) {
            echo "<ul class='category-list'>";
            while ($inventory_row = $inventory_result->fetch_assoc()) {
                echo "<li>" . $inventory_row["gear_name"] . "</li>";
            }
            echo "</ul>";
        } else {
            echo "No equipment available for this gear type.";
        }

        echo "</div>";
    }
} else {
    echo "No gear types available at the moment.";
}

// Close connection
$conn->close();
?>

    </section>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Adventure Gear Rental</p>
    </footer>

</body>

</html>
