
        const gearData = [
            { id: 1, name: 'Kayak', price: 3000 },
            { id: 2, name: 'Snorkel Set', price: 800 },
            { id: 3, name: 'Paddleboard', price: 2500 },
            // Add more gear items as needed
        ];

        function displayGear() {
            const gearListDiv = document.getElementById('gear-list');

            gearData.forEach(gear => {
                const gearItemDiv = document.createElement('div');
                gearItemDiv.classList.add('gear-item');
                gearItemDiv.innerHTML = `
                    <span>${gear.name} - KES ${gear.price.toLocaleString()}</span>
                    <button onclick="rentGear(${gear.id})">Rent</button>
                `;
                gearListDiv.appendChild(gearItemDiv);
            });
        }

        function rentGear(gearId) {
            alert(`You rented gear with ID ${gearId}. This is a dummy function.`);
        }

        window.onload = displayGear;
