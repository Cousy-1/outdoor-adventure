<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles_signup.css"> <!-- Add your CSS file for styling -->
    <title>Outdoor Adventure Signup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .signup-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .signup-container h2 {
            margin-bottom: 20px;
            color: #007bff;
            text-align: center;
        }

        .signup-container form label {
            display: block;
            margin-bottom: 10px;
        }

        .signup-container form input[type="text"],
        .signup-container form input[type="email"],
        .signup-container form input[type="tel"],
        .signup-container form input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .signup-container form button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .signup-container form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
  <?php
// Assuming you have a MySQL connection
$servername = "localhost"; // Change to your MySQL server hostname or IP address
$username = "root";
$password = "";
$dbname = "outdooradventure_equipments";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT); // Hash the password
    

    // Insert data into the table (assuming the table is named 'user_accounts')
    $sql = "INSERT INTO user_accounts (name, email, phone, password) VALUES ('$name', '$email', '$phone', '$password')";

    if ($conn->query($sql) === TRUE) {
        // Redirect to the login page
        header("Location: outdoor_login.php");
        exit(); // Ensure that subsequent code is not executed after redirection
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>


    <div class="signup-container">
        <h2>Sign Up for Outdoor Adventure</h2>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Phone:</label>
            <input type="tel" id="phone" name="phone" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit">Sign Up</button>
        </form>
        <div class="login-link">
            Already have an account? <a href="outdoor_login.php">Login here</a>
        </div>
        <div class="login-link">
            Signup as Admin? <a href="outdooradmin_signup.php">signup here</a>
        </div>
    </div>
</body>

</html>
