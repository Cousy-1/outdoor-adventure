<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; 
$database = "outdooradventure_equipments";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Login process
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    
    $password = $_POST['password'];

    // Query to check if the user exists
    $sql = "SELECT * FROM user_accounts WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // User exists, redirect to appropriate dashboard
        $row = $result->fetch_assoc();
        if ($row['role'] == 'admin') {
            header("Location: adminoagrs_dashboard.php");
            exit();
        } else {
            header("Location: adminoagrs_dashboard.php"); // Redirect to regular user dashboard
            exit();
        }
    } else {
        // User doesn't exist or invalid credentials
        echo "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
     <link rel="stylesheet" href="styles_login.css">
</head>
<body>
    <h2>Login as Admin</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="name">Name:</label><br>
        <input type="text" id="name" name="name" required><br><br>
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        <label for="staff_no">Staff Number:</label><br> <!-- Added staff number field -->
        <input type="text" id="staff_no" name="staff_no" required><br><br>
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
