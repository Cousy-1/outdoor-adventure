
const gearData = [
    { id: 1, name: 'Hiking Backpack', price: 700 },
    { id: 2, name: 'Trekking Poles', price: 300 },
    { id: 3, name: 'Waterproof Jacket', price: 1500 },
    // Add more gear items as needed
];
        function displayGear() {
            const gearListDiv = document.getElementById('gear-list');

            gearData.forEach(gear => {
                const gearItemDiv = document.createElement('div');
                gearItemDiv.classList.add('gear-item');
                gearItemDiv.innerHTML = `
                    <span>${gear.name} - KES ${gear.price.toLocaleString()}</span>
                    <button onclick="rentGear(${gear.id})">Rent</button>
                `;
                gearListDiv.appendChild(gearItemDiv);
            });
        }

        function rentGear(gearId) {
            alert(`You rented gear with ID ${gearId}. This is a dummy function.`);
        }

        window.onload = displayGear;
