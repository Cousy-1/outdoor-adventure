
        const accessoriesData = [
            { id: 1, name: 'Bike Helmet', price: 800 },
            { id: 2, name: 'Cycling Gloves', price: 500 },
            { id: 3, name: 'Bike Lock', price: 300 },
            // Add more accessory items as needed
        ];

        function displayAccessories() {
            const accessoriesListDiv = document.getElementById('accessories-list');

            accessoriesData.forEach(accessory => {
                const accessoryItemDiv = document.createElement('div');
                accessoryItemDiv.classList.add('gear-item');
                accessoryItemDiv.innerHTML = `
                    <span>${accessory.name} - KES ${accessory.price.toLocaleString()}</span>
                    <button onclick="rentAccessory(${accessory.id})">Rent</button>
                `;
                accessoriesListDiv.appendChild(accessoryItemDiv);
            });
        }

        function rentAccessory(accessoryId) {
            alert(`You rented accessory with ID ${accessoryId}. This is a dummy function.`);
        }

        window.onload = displayAccessories;
    
